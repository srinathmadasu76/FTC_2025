package org.firstinspires.ftc.teamcode.Commands.Shoot;

import com.seattlesolvers.solverslib.command.InstantCommand;
import com.seattlesolvers.solverslib.command.SequentialCommandGroup;
import com.seattlesolvers.solverslib.command.WaitCommand;

import org.firstinspires.ftc.teamcode.Subsystem.Intake;
import org.firstinspires.ftc.teamcode.Subsystem.Kicker;

public class KickTransferCycle extends SequentialCommandGroup {

    // Timing (milliseconds)
    public static final long KICK_UP_TIME_MS      = 180; // how long kicker stays up
    public static final long KICK_DOWN_SETTLE_MS  = 150;  // small settle time after coming down
    public static final long FEED_TIME_MS         = 20; // intake feed pulse

    public KickTransferCycle(Kicker kicker, Intake intake) {
        addRequirements(kicker, intake);

        addCommands(
                // Kick up
                new InstantCommand(kicker::setUp),
                new InstantCommand(intake::disable),
                new WaitCommand(KICK_UP_TIME_MS),

                // Kick down (then only a short settle wait)
                new InstantCommand(kicker::setDown),
                new WaitCommand(KICK_DOWN_SETTLE_MS),

                // Feed
                new InstantCommand(intake::enable),
                new WaitCommand(FEED_TIME_MS),
                new InstantCommand(intake::disable)
        );
    }
}
