package org.firstinspires.ftc.teamcode.Teleop;

import com.acmerobotics.dashboard.FtcDashboard;
import com.acmerobotics.dashboard.telemetry.MultipleTelemetry;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;


import com.seattlesolvers.solverslib.command.CommandOpMode;

import org.firstinspires.ftc.teamcode.Subsystem.Shooter;

@TeleOp(name = "ShooterTuner (Dashboard)", group = "Tuning")
public class ShooterTuner extends CommandOpMode {

    private Shooter shooter;

    @Override
    public void initialize() {
        // Telemetry to BOTH DS and Dashboard
        telemetry = new MultipleTelemetry(telemetry, FtcDashboard.getInstance().getTelemetry());

        shooter = new Shooter(hardwareMap, "shooter", telemetry);

        // Start safe: stopped. You will set targetTPS_dash in Dashboard.
        Shooter.useDashTarget = true;
        Shooter.targetTPS_dash = 0.0;

        telemetry.addLine("ShooterTuner ready.");
        telemetry.addLine("Dashboard -> Config -> Shooter");
        telemetry.addLine("Set targetTPS_dash, then tune kF, then kP, then (optional) kD.");
        telemetry.update();
    }

    @Override
    public void run() {
        super.run();

        // Force Shooter loop to run no matter what
        shooter.periodic();

        telemetry.update();
    }
}

