package org.firstinspires.ftc.teamcode.Subsystem;


import com.qualcomm.robotcore.hardware.HardwareMap;
import com.seattlesolvers.solverslib.command.SubsystemBase;
import com.seattlesolvers.solverslib.hardware.servos.ServoEx;

import org.firstinspires.ftc.robotcore.external.Telemetry;

public class Kicker extends SubsystemBase {
    private final ServoEx kicker;
    private double lastPos = 0.0;

    // Tune these
    public static final double DOWN = 0.5;
    public static final double UP   = 0.22;

    public Kicker(final HardwareMap hwMap, final String name, Telemetry telemetry) {
        kicker = new ServoEx(hwMap, name);
        setDown();
    }

    public void setPosition(double position) {
        lastPos = position;
        kicker.set(position);
    }

    public void setDown() {
        setPosition(DOWN);
    }

    public void setUp() {
        setPosition(UP);
    }

    public double getLastPosition() {
        return lastPos;
    }
}
