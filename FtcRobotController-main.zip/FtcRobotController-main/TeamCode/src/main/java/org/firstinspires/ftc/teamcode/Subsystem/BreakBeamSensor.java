package org.firstinspires.ftc.teamcode.Subsystem;

import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.seattlesolvers.solverslib.command.SubsystemBase;

public class BreakBeamSensor extends SubsystemBase {

    private final DigitalChannel breakBeamSensor;

    private int artifactCount;
    private boolean hasBeamBroken;

    // Your configured hardware name should be "breakbeam" (no space) in the RC config
    public BreakBeamSensor(HardwareMap hwMap) {
        this(hwMap, "breakbeam");
    }

    public BreakBeamSensor(HardwareMap hwMap, String name) {
        breakBeamSensor = hwMap.get(DigitalChannel.class, name);
        breakBeamSensor.setMode(DigitalChannel.Mode.INPUT);

        // Avoid a false count if the beam starts broken
        hasBeamBroken = isBeamBroken();
        artifactCount = 0;
    }

    /** Most break beams are active-low: state=false means beam is broken */
    public boolean isBeamBroken() {
        return !breakBeamSensor.getState();
    }

    /** Total number of "beam break" events detected (edge-counted) */
    public int getArtifactCount() {
        return artifactCount;
    }

    /** Optional helper if you want to reset count (ex: at start of match) */
    public void resetCount() {
        artifactCount = 0;
    }

    @Override
    public void periodic() {
        boolean broken = isBeamBroken();

        // Rising edge: unbroken -> broken
        if (broken && !hasBeamBroken) {
            artifactCount++;
            hasBeamBroken = true;
        }
        // Falling edge: broken -> unbroken
        else if (!broken && hasBeamBroken) {
            hasBeamBroken = false;
        }
    }
}
