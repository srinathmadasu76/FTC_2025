package org.firstinspires.ftc.teamcode.Auton;

import com.pedropathing.control.PIDFCoefficients;
import com.pedropathing.control.PIDFController;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.teamcode.Pedro.Constants;

@Autonomous(name = "Red_RearHumanPlayer_PP_vB_FIXED_NO_CONSEC", group = "Auton")
public class Red_RearHumanPlayer_PP_vB_5shoots_UPDATED extends OpMode {

    // ---------------- Pedro follower ----------------
    private Follower follower;

    // ---------------- Hardware ----------------
    private Servo ballStopper = null; // "ballKick"
    private Servo hood = null;        // "hood"
    private Servo turret = null;      // "turret"
    private DcMotor ShooterMotor = null; // "shooter"
    private DcMotor IntakeMotor = null;  // "intake"
    private DigitalChannel beamBreakSensor = null; // "breakbeam"

    // ---------------- Turret ----------------
    private static final String TURRET_SERVO_NAME = "turret";
    private static final double TURRET_CENTER_POS = 0.47;
    private static final double TURRET_DEG_PER_POS = 355.0;
    private static final double SERVO_MIN_POS = 0.0;
    private static final double SERVO_MAX_POS = 1.0;

    private static final double TURRET_INIT_DEG = 98;

    private static double turretDegToServoPos(double turretDeg) {
        double servoPos = TURRET_CENTER_POS + (turretDeg / TURRET_DEG_PER_POS);
        return Range.clip(servoPos, SERVO_MIN_POS, SERVO_MAX_POS);
    }

    private void setTurretDeg(double deg) {
        if (turret != null) turret.setPosition(turretDegToServoPos(deg));
    }

    // ---------------- Shooter PIDF ----------------
    private PIDFController b, s;

    public static double bp = 0.01, bd = 0.0, bf = 0.0,
            sp = 0.01, sd = 0.0001, sf = 0.0;

    private double pSwitch = 50;
    private double targetvel = 1600;

    // Ready rules
    private static final double SHOOTER_READY_TOL = 200;      // ticks/sec
    private static final double SHOOTER_READY_TIMEOUT = 1.0;  // normal scoring timeout
    private static final double PRELOAD_READY_TIMEOUT = 5.0;  // preload spins longer

    private void updateShooterPID() {
        double currentvel = ((DcMotorEx) ShooterMotor).getVelocity();

        b.setCoefficients(new PIDFCoefficients(bp, 0, bd, bf));
        s.setCoefficients(new PIDFCoefficients(sp, 0, sd, sf));

        double err = targetvel - currentvel;
        if (Math.abs(err) < pSwitch) {
            s.updateError(err);
            ShooterMotor.setPower(s.run());
        } else {
            b.updateError(err);
            ShooterMotor.setPower(b.run());
        }
    }

    private boolean shooterAtSpeed(double tol) {
        double v = ((DcMotorEx) ShooterMotor).getVelocity();
        return Math.abs(targetvel - v) <= tol;
    }

    // ---------------- Breakbeam ----------------
    // Active-low: false = broken
    private boolean isBeamBroken() {
        return beamBreakSensor != null && !beamBreakSensor.getState();
    }

    // ---------------- Intake ----------------
    private double pickupIntakePower = -1.0;
    private double searchIntakePower = -0.4;
    private double transferIntakePower = -1.0;

    private void startLaneIntake() { IntakeMotor.setPower(pickupIntakePower); }
    private void stopLaneIntake()  { IntakeMotor.setPower(0.0); }

    // ---------------- Kicker / feeder ----------------
    private double ballkicker_up = 0.22;
    private double ballkicker_down = 0.5;

    // YOU REQUESTED: kicker up time = 0.23s
    private double waittime = 0.23;

    private double waittime_transfer = 0.2;
    private static final int SHOT_CYCLES = 3;

    // ---------------- Field mirroring helpers ----------------
    // Pedro Decode field spans [0,144] on x and y.
    private static final double FIELD_SIZE = 144.0;

    private static double wrapRad(double a) {
        while (a <= -Math.PI) a += 2.0 * Math.PI;
        while (a >  Math.PI) a -= 2.0 * Math.PI;
        return a;
    }

    // Mirror Blue->Red across the horizontal midline (y=72): (x, y, h) -> (x, 144-y, -h)
    private static Pose mirrorToRed(Pose blue) {
        return new Pose(
                blue.getX(),
                FIELD_SIZE - blue.getY(),
                wrapRad(-blue.getHeading())
        );
    }

    // ---------------- PP path list ----------------
    private final Pose scorePoint = new Pose(58, 135, Math.toRadians(180));
    private static final double SCORE_RADIUS_IN = 1.5;

    // This is used only to tag endpoints as "score endpoints" reliably.
    private static final double SCORE_MATCH_TOL_IN = 0.25;

    private Pose ppStartPose;
    private Pose[] ppEnds;
    private PathChain[] ppPaths;
    private boolean[] endIsScore;

    // Stuck protection (skip current path after timeout)
    private static final double PATH_TIMEOUT_SEC = 3.0;
    private double pathStartSec = 0.0;

    private void buildPathsFromPP() {
        // --------- Your ORIGINAL blue poses ----------
        Pose blueStart = new Pose(58, 9, Math.toRadians(180));

        Pose[] blueEnds = new Pose[] {
                new Pose(58, 36, Math.toRadians(180)), // 1
                new Pose(18, 36, Math.toRadians(180)), // 2
                new Pose(58, 9,  Math.toRadians(180)), // 3 (score)
                new Pose(15, 9,  Math.toRadians(180)), // 4
                new Pose(58, 9,  Math.toRadians(180)), // 5 (score)
                new Pose(17, 9,  Math.toRadians(180)), // 6
                new Pose(20, 9,  Math.toRadians(180)), // 7
                new Pose(17, 9,  Math.toRadians(180)), // 8
                new Pose(58, 9,  Math.toRadians(180)), // 9 (score)
                new Pose(18, 9,  Math.toRadians(180)), // 10
                new Pose(58, 9,  Math.toRadians(180)), // 11 (score)
                new Pose(58, 36, Math.toRadians(180)), // 12
        };

        // --------- Mirror them to RED ----------
        ppStartPose = mirrorToRed(blueStart);

        ppEnds = new Pose[blueEnds.length];
        for (int i = 0; i < blueEnds.length; i++) {
            ppEnds[i] = mirrorToRed(blueEnds[i]);
        }

        // Tag endpoints that are score endpoints
        endIsScore = new boolean[ppEnds.length];
        for (int i = 0; i < ppEnds.length; i++) {
            endIsScore[i] = distXY(ppEnds[i], scorePoint) <= SCORE_MATCH_TOL_IN;
        }

        // --------- Build path chains ----------
        ppPaths = new PathChain[ppEnds.length];

        Pose cur = ppStartPose;
        for (int i = 0; i < ppEnds.length; i++) {
            Pose next = ppEnds[i];

            ppPaths[i] = follower.pathBuilder()
                    .addPath(new BezierLine(cur, next))
                    .setConstantHeadingInterpolation(Math.toRadians(180))
                    .build();

            cur = next;
        }
    }

    private static double distXY(Pose a, Pose b) {
        double dx = a.getX() - b.getX();
        double dy = a.getY() - b.getY();
        return Math.hypot(dx, dy);
    }

    private boolean atScore() {
        return distXY(follower.getPose(), scorePoint) <= SCORE_RADIUS_IN;
    }

    // ---------------- Non-blocking spinup gate ----------------
    private boolean spinupActive = false;
    private double spinupStartSec = 0;
    private double spinupTimeoutSec = SHOOTER_READY_TIMEOUT;

    private void startSpinupGate(double timeoutSeconds) {
        spinupActive = true;
        spinupStartSec = getRuntime();
        spinupTimeoutSec = timeoutSeconds;
    }

    private boolean spinupGateDone() {
        if (!spinupActive) return true;
        boolean ready = shooterAtSpeed(SHOOTER_READY_TOL);
        boolean timedOut = (getRuntime() - spinupStartSec) >= spinupTimeoutSec;

        if (ready) {
            spinupActive = false;
            return true;
        }

        if (timedOut) {
            // Don't feed if not ready
            spinupActive = false;
            return false;
        }

        return false;
    }

    // ---------------- Non-blocking feeder ----------------
    private enum FeedPhase { IDLE, KICK_UP, KICK_DOWN_WAIT_BEAM, SETTLE }
    private FeedPhase feedPhase = FeedPhase.IDLE;
    private int feedCyclesRemaining = 0;
    private double phaseStartSec = 0;

    private void startFeeder(int cycles) {
        feedCyclesRemaining = cycles;
        feedPhase = FeedPhase.KICK_UP;
        phaseStartSec = getRuntime();
        IntakeMotor.setPower(0.0);
        ballStopper.setPosition(ballkicker_up);
    }

    private boolean updateFeeder() {
        if (feedPhase == FeedPhase.IDLE) return true;

        double now = getRuntime();

        switch (feedPhase) {
            case KICK_UP:
                if ((now - phaseStartSec) >= waittime) {
                    ballStopper.setPosition(ballkicker_down);
                    feedPhase = FeedPhase.KICK_DOWN_WAIT_BEAM;
                    phaseStartSec = now;
                }
                break;

            case KICK_DOWN_WAIT_BEAM:
                if (isBeamBroken()) {
                    IntakeMotor.setPower(transferIntakePower);
                    feedPhase = FeedPhase.SETTLE;
                    phaseStartSec = now;
                } else {
                    IntakeMotor.setPower(searchIntakePower);
                }

                // safety: don't hang forever waiting for beam
                if ((now - phaseStartSec) > 1.0) {
                    feedPhase = FeedPhase.SETTLE;
                    phaseStartSec = now;
                }
                break;

            case SETTLE:
                if ((now - phaseStartSec) >= waittime_transfer) {
                    IntakeMotor.setPower(0.0);
                    feedCyclesRemaining--;
                    if (feedCyclesRemaining <= 0) {
                        ballStopper.setPosition(ballkicker_down);
                        feedPhase = FeedPhase.IDLE;
                        return true;
                    } else {
                        ballStopper.setPosition(ballkicker_up);
                        feedPhase = FeedPhase.KICK_UP;
                        phaseStartSec = now;
                    }
                }
                break;

            default:
                break;
        }

        return false;
    }

    // ---------------- Main auton ----------------
    private enum AutoState { PRELOAD_FEED, RUN_PATHS, SCORE_FEED, DONE }
    private AutoState state = AutoState.PRELOAD_FEED;

    private int ppIndex = 0;

    private void startNextPPPath() {
        if (ppIndex < ppPaths.length) {
            follower.followPath(ppPaths[ppIndex], true);
            ppIndex++;
            pathStartSec = getRuntime();
        } else {
            state = AutoState.DONE;
        }
    }

    private void handlePathTimeoutIfNeeded() {
        if (!follower.isBusy()) return;

        double elapsed = getRuntime() - pathStartSec;
        if (elapsed >= PATH_TIMEOUT_SEC) {
            // Skip current path and go next
            startNextPPPath();
        }
    }

    @Override
    public void init() {
        follower = Constants.createFollower(hardwareMap);

        ballStopper = hardwareMap.get(Servo.class, "ballKick");
        IntakeMotor  = hardwareMap.dcMotor.get("intake");
        ShooterMotor = hardwareMap.dcMotor.get("shooter");
        hood         = hardwareMap.get(Servo.class, "hood");
        turret       = hardwareMap.get(Servo.class, TURRET_SERVO_NAME);

        beamBreakSensor = hardwareMap.get(DigitalChannel.class, "breakbeam");
        beamBreakSensor.setMode(DigitalChannel.Mode.INPUT);

        buildPathsFromPP();
        follower.setStartingPose(ppStartPose);

        ballStopper.setPosition(ballkicker_down);
        hood.setPosition(0.24);
        stopLaneIntake();
        setTurretDeg(TURRET_INIT_DEG);

        b = new PIDFController(new PIDFCoefficients(bp, 0, bd, bf));
        s = new PIDFController(new PIDFCoefficients(sp, 0, sd, sf));

        targetvel = 1650;

        // reset state
        feedPhase = FeedPhase.IDLE;
        spinupActive = false;
        ppIndex = 0;

        // Preload: longer spinup gate
        startSpinupGate(PRELOAD_READY_TIMEOUT);
        state = AutoState.PRELOAD_FEED;
    }

    @Override
    public void start() {
        // nothing special; init already armed preload gate
    }

    @Override
    public void loop() {
        updateShooterPID();
        follower.update();

        switch (state) {

            // Preload shooting event #1
            case PRELOAD_FEED:
                if (spinupGateDone()) {
                    if (feedPhase == FeedPhase.IDLE) startFeeder(SHOT_CYCLES);

                    if (updateFeeder()) {
                        startLaneIntake();
                        startNextPPPath();
                        state = AutoState.RUN_PATHS;
                    }
                }
                break;

            case RUN_PATHS:
                // stuck protection
                handlePathTimeoutIfNeeded();

                // When a path finishes, decide what to do based on the endpoint we just reached.
                if (!follower.isBusy()) {

                    int lastFinishedIndex = ppIndex - 1; // ppIndex already incremented when we started it
                    boolean finishedAtScore = (lastFinishedIndex >= 0
                            && lastFinishedIndex < endIsScore.length
                            && endIsScore[lastFinishedIndex]);

                    if (finishedAtScore) {
                        // We arrived at a score endpoint -> shoot
                        stopLaneIntake();
                        startSpinupGate(SHOOTER_READY_TIMEOUT);
                        state = AutoState.SCORE_FEED;
                        break;
                    } else {
                        // Not a score endpoint -> keep intaking and go next
                        startLaneIntake();
                        startNextPPPath();
                    }
                }
                break;

            case SCORE_FEED:
                hood.setPosition(0.24);

                if (spinupGateDone()) {
                    if (feedPhase == FeedPhase.IDLE) startFeeder(SHOT_CYCLES);

                    if (updateFeeder()) {
                        startLaneIntake();
                        if (!follower.isBusy()) startNextPPPath();
                        state = AutoState.RUN_PATHS;
                    }
                }
                break;

            case DONE:
                stopLaneIntake();
                ShooterMotor.setPower(0.0);
                ballStopper.setPosition(ballkicker_down);
                break;
        }

        telemetry.addData("state", state);
        telemetry.addData("ppIndex_next", ppIndex);
        telemetry.addData("busy", follower.isBusy());
        telemetry.addData("x", follower.getPose().getX());
        telemetry.addData("y", follower.getPose().getY());
        telemetry.addData("heading(deg)", Math.toDegrees(follower.getPose().getHeading()));
        telemetry.addData("atScore", atScore());
        telemetry.addData("beamBroken", isBeamBroken());
        telemetry.addData("intakePower", IntakeMotor.getPower());
        telemetry.addData("targetVel", targetvel);
        telemetry.addData("shooterVel", ((DcMotorEx) ShooterMotor).getVelocity());
        telemetry.addData("feedPhase", feedPhase);
        telemetry.addData("feedCyclesRemaining", feedCyclesRemaining);
        telemetry.update();
    }

    @Override
    public void stop() {
        if (IntakeMotor != null) IntakeMotor.setPower(0.0);
        if (ShooterMotor != null) ShooterMotor.setPower(0.0);
    }
}
