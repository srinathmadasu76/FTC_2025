package org.firstinspires.ftc.teamcode.Subsystem;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.Range;
import com.seattlesolvers.solverslib.command.SubsystemBase;
import com.seattlesolvers.solverslib.controller.PIDFController;
import com.seattlesolvers.solverslib.hardware.motors.MotorEx;

import org.firstinspires.ftc.robotcore.external.Telemetry;

@Config
public class Shooter extends SubsystemBase {

    public final MotorEx shooter;

    // =========================
    // FTC Dashboard tunables
    // =========================
    public static double kP = 0.0038;
    public static double kI = 0.0;
    public static double kD = 0.0;
    public static double kF = 0.000417;

    // IMPORTANT: default FALSE so TeleOp setVelocity works
    public static boolean useDashTarget = false;

    // Dashboard setpoint (only used when useDashTarget == true)
    public static double targetTPS_dash = 0.0;

    public static double velAlpha = 0.25;
    public static double maxPower = 1.0;
    public static double minTargetTPS = 1.0;

    // =========================
    // Internal state
    // =========================
    private final PIDFController shooterPID = new PIDFController(kP, kI, kD, kF);
    private final Telemetry telemetry;

    private double targetTPS = 0.0;
    private double filteredVel = 0.0;

    public Shooter(final HardwareMap hwMap, final String name, Telemetry telemetry) {
        this.telemetry = telemetry;

        shooter = new MotorEx(hwMap, name);
        shooter.setZeroPowerBehavior(MotorEx.ZeroPowerBehavior.FLOAT);
    }

    /** Switch between Dashboard-driven setpoint and code-driven setpoint. */
    public void setUseDashTarget(boolean enabled) {
        useDashTarget = enabled;
    }

    /** ticks per second (must match MotorEx.getVelocity() units) */
    public void setVelocity(double ticksPerSecond) {
        targetTPS = Math.max(0.0, ticksPerSecond);
        targetTPS_dash = targetTPS;              // keeps dashboard number matching (optional)
        shooterPID.setSetPoint(targetTPS);
    }

    public double getTargetVelocity() {
        return targetTPS;
    }

    public double getCurrentVelocity() {
        return shooter.getVelocity();
    }

    public void stop() {
        setVelocity(0.0);
        shooter.set(0.0);
    }

    @Override
    public void periodic() {
        shooterPID.setPIDF(kP, kI, kD, kF);

        // Choose setpoint source
        if (useDashTarget) {
            // Use dashboard setpoint
            targetTPS = Math.max(0.0, targetTPS_dash);
            shooterPID.setSetPoint(targetTPS);
        } else {
            // Use whatever TeleOp last set
            shooterPID.setSetPoint(targetTPS);
        }

        double vel = shooter.getVelocity();

        filteredVel = filteredVel + (vel - filteredVel) * velAlpha;

        if (targetTPS < minTargetTPS) {
            shooter.set(0.0);
            if (telemetry != null) {
                telemetry.addData("sh_tgt_tps", targetTPS);
                telemetry.addData("sh_vel_tps", vel);
                telemetry.addData("sh_fvel_tps", filteredVel);
                telemetry.addData("sh_out", 0.0);
            }
            return;
        }

        double out = shooterPID.calculate(filteredVel);
        out = Range.clip(out, 0.0, maxPower);

        shooter.set(out);

        if (telemetry != null) {
            telemetry.addData("sh_tgt_tps", targetTPS);
            telemetry.addData("sh_vel_tps", vel);
            telemetry.addData("sh_fvel_tps", filteredVel);
            telemetry.addData("sh_out", out);

            telemetry.addData("kP", kP);
            telemetry.addData("kI", kI);
            telemetry.addData("kD", kD);
            telemetry.addData("kF", kF);
            telemetry.addData("useDashTarget", useDashTarget);
        }
    }
}
