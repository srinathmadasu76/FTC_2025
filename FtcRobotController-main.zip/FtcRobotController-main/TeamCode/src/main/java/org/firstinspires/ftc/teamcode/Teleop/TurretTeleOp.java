package org.firstinspires.ftc.teamcode.Teleop;

import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.teamcode.Subsystem.Turret;

@TeleOp(name = "Turret TeleOp (Y = Zero+Track 53)", group = "TeleOp")
public class TurretTeleOp extends OpMode {

    private Turret turret;
    private GoBildaPinpointDriver pinpoint;

    // ===== GOAL FIELD HEADING =====
    // This is a FIELD heading you want the turret to keep pointing at.
    private static final double GOAL_FIELD_HEADING_DEG = 53.0;

    // ===== TRACKING SETTINGS =====
    private static final double RATE_LIMIT_DEG_PER_SEC = 240.0;

    // Debounce Y
    private boolean yPrev = false;

    // dt for rate limiting
    private long lastLoopNs = 0L;

    // Tracking enable + target
    private boolean tracking = false;
    private double targetFieldDeg = GOAL_FIELD_HEADING_DEG;

    @Override
    public void init() {
        turret = new Turret(hardwareMap, "turret");

        pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, "pinpoint");
        pinpoint.setOffsets(-84.0, -168.0, DistanceUnit.MM);
        pinpoint.setEncoderResolution(GoBildaPinpointDriver.GoBildaOdometryPods.goBILDA_4_BAR_POD);
        pinpoint.setEncoderDirections(
                GoBildaPinpointDriver.EncoderDirection.FORWARD,
                GoBildaPinpointDriver.EncoderDirection.FORWARD
        );

        telemetry.addLine("Turret TeleOp ready.");
        telemetry.addLine("Press Y: Zero Pinpoint + start tracking target FIELD heading.");
        telemetry.addData("Target Field Heading", "%.1f deg", GOAL_FIELD_HEADING_DEG);
        telemetry.update();

        lastLoopNs = System.nanoTime();
    }

    @Override
    public void loop() {
        pinpoint.update();

        // dt
        long nowNs = System.nanoTime();
        double dt = (nowNs - lastLoopNs) / 1e9;
        lastLoopNs = nowNs;
        if (dt <= 0) dt = 0.02;

        // ===== Y: ONE-TAP ZERO+TRACK =====
        boolean y = gamepad1.y;
        if (y && !yPrev) {
            // 1) Zero pinpoint pose+heading (robot must be squared first)
            pinpoint.resetPosAndIMU();

            // 2) Enable tracking and lock the FIELD target
            targetFieldDeg = GOAL_FIELD_HEADING_DEG;
            tracking = true;

            // 3) Immediately command turret to the *robot-relative* angle needed right now
            double robotHeadingDeg = getRobotHeadingDeg();
            double initialTargetRobotDeg = wrapDeg(targetFieldDeg - robotHeadingDeg); // <-- correct sign
            initialTargetRobotDeg = turret.clampDegrees(initialTargetRobotDeg);
            turret.setTurretDegrees(initialTargetRobotDeg);

            gamepad1.rumble(300);
        }
        yPrev = y;

        // ===== TRACKING =====
        double robotHeadingDeg = getRobotHeadingDeg();

        // Compute desired turret angle in ROBOT frame that points to the FIELD target.
        // If it ever tracks backwards for your build, flip this sign:
        //   wrapDeg(robotHeadingDeg - targetFieldDeg)
        double turretTargetDegRobot_Unclamped = wrapDeg(targetFieldDeg - robotHeadingDeg);

        // Respect hard limits
        double turretTargetDegRobot = turret.clampDegrees(turretTargetDegRobot_Unclamped);

        // Smooth move (rate limit)
        if (tracking) {
            double currentDeg = turret.getDegrees();
            double errDeg = wrapDeg(turretTargetDegRobot - currentDeg);

            double maxStep = RATE_LIMIT_DEG_PER_SEC * dt;
            double step = clamp(errDeg, -maxStep, maxStep);

            turret.setTurretDegrees(currentDeg + step);
        }

        // ===== TELEMETRY / DEBUG =====
        double minDeg = turret.getMinDegrees();
        double maxDeg = turret.getMaxDegrees();
        boolean clamping = Math.abs(turretTargetDegRobot_Unclamped - turretTargetDegRobot) > 1.0;

        telemetry.addData("Tracking", tracking);
        telemetry.addData("Target Field", "%.1f deg", targetFieldDeg);
        telemetry.addData("Robot Heading", "%.1f deg", robotHeadingDeg);

        telemetry.addData("Turret Deg (cmd)", "%.1f deg", turret.getDegrees());
        telemetry.addData("Turret Range", "[%.1f, %.1f] deg", minDeg, maxDeg);

        telemetry.addData("TargetRobot (raw)", "%.1f deg", turretTargetDegRobot_Unclamped);
        telemetry.addData("TargetRobot (clamped)", "%.1f deg", turretTargetDegRobot);
        telemetry.addData("CLAMPING?", clamping);

        telemetry.addData("Servo Pos", "%.3f", turret.getLastPosition());
        telemetry.addData("Pinpoint Status", pinpoint.getDeviceStatus());
        telemetry.update();
    }

    private double getRobotHeadingDeg() {
        double headingRad = pinpoint.getHeading(AngleUnit.RADIANS);
        return wrapDeg(Math.toDegrees(headingRad));
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static double wrapDeg(double d) {
        d = (d + 180.0) % 360.0;
        if (d < 0) d += 360.0;
        return d - 180.0;
    }
}
