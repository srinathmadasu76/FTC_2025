package org.firstinspires.ftc.teamcode.Subsystem;

import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.Pose;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.seattlesolvers.solverslib.command.SubsystemBase;
import com.seattlesolvers.solverslib.gamepad.GamepadEx;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.Pedro.Constants;

public class Drive extends SubsystemBase {
    private final GamepadEx gamepadEx;   // may be null in auton constructor
    public final Follower follower;      // make final so it can’t accidentally stay null
    private Pose pose;
    private final Telemetry telemetry;

    // TeleOp constructor
    public Drive(HardwareMap hw, GamepadEx gamepadEx, Telemetry telemetry) {
        this.gamepadEx = gamepadEx;
        this.telemetry = telemetry;

        // ✅ MUST initialize follower or you'll get NullPointerExceptions
        follower = Constants.createFollower(hw);

        // Optional: start teleop drive mode immediately
        follower.startTeleopDrive(true);
    }

    // Non-teleop constructor (no gamepad)
    public Drive(HardwareMap hw, Telemetry telemetry) {
        this.gamepadEx = null;
        this.telemetry = telemetry;

        // ✅ MUST initialize follower
        follower = Constants.createFollower(hw);
    }

    public Pose getPose() {
        return follower.getPose();
    }

    public void holdPoint() {
        follower.holdPoint(follower.getPose());
    }

    /** Call this if you want to explicitly start teleop drive later. */
    public void teleopDrive() {
        follower.startTeleopDrive(true);
    }

    @Override
    public void periodic() {
        // If we have a gamepad, apply joystick commands
        if (gamepadEx != null) {
            follower.setTeleOpDrive(
                    gamepadEx.getLeftY(),
                    -gamepadEx.getLeftX(),
                    -gamepadEx.getRightX()
            );
        }

        // Update pose + follower each loop
        pose = follower.getPose();
        follower.update();

        // Optional debug
        // telemetry.addData("DrivePose", pose);
    }
}
