package org.firstinspires.ftc.teamcode.Subsystem;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

public class Turret {

    private final Servo servo;

    // Servo mechanical travel you are assuming (deg). Calibrate if needed.
    private static final double SERVO_RANGE_DEG = 355 * 0.869;
// ≈ 308


    // turretDeg = servoDeg * GEAR
    // If your tracking sign is flipped, you can make this NEGATIVE instead of changing math elsewhere.
    // (You said you need negative sign for tracking; keeping GEAR positive is fine since we flipped sign in TeleOp.)
    private static final double GEAR =  0.9393;

    // Safe servo range (hard stops / no-binding range)
    private static final double POS_MIN = 0.12;
    private static final double POS_MAX = 0.82;
    private static final double MID_POS = 0.47;

    private double lastPos = MID_POS;

    public Turret(HardwareMap hwMap, String name) {
        servo = hwMap.get(Servo.class, name);
        setPosition(MID_POS);
    }

    /** Set turret angle in robot-relative degrees (0 = centered). */
    public void setTurretDegrees(double turretDeg) {
        double servoDeg = turretDeg / GEAR;
        double pos = MID_POS + (servoDeg / SERVO_RANGE_DEG);
        setPosition(pos);
    }

    /** Get turret angle in robot-relative degrees (0 = centered). */
    public double getDegrees() {
        double servoDeg = (lastPos - MID_POS) * SERVO_RANGE_DEG;
        return servoDeg * GEAR;
    }

    /** Direct servo position command (clamped). */
    public void setPosition(double pos) {
        pos = clamp(pos, POS_MIN, POS_MAX);
        lastPos = pos;
        servo.setPosition(pos);
    }

    public double getLastPosition() {
        return lastPos;
    }

    /** Convenience: center turret (0 degrees). */
    public void center() {
        setPosition(MID_POS);
    }

    public void stop() {
        servo.setPosition(lastPos);
    }

    /** Smallest reachable turret angle (deg) based on POS_MIN */
    public double getMinDegrees() {
        double servoDeg = (POS_MIN - MID_POS) * SERVO_RANGE_DEG;
        return servoDeg * GEAR;
    }

    /** Largest reachable turret angle (deg) based on POS_MAX */
    public double getMaxDegrees() {
        double servoDeg = (POS_MAX - MID_POS) * SERVO_RANGE_DEG;
        return servoDeg * GEAR;
    }

    /** Clamp a desired turret angle into safe range */
    public double clampDegrees(double turretDeg) {
        return clamp(turretDeg, getMinDegrees(), getMaxDegrees());
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
