// =======================
// Intake.java (UPDATED)
// LB mode = current detect ON
// RB mode = current detect BYPASS
// =======================
package org.firstinspires.ftc.teamcode.Subsystem;

import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.seattlesolvers.solverslib.command.SubsystemBase;

import org.firstinspires.ftc.robotcore.external.navigation.CurrentUnit;

public class Intake extends SubsystemBase {

    private final DcMotorEx intakeMotor;

    public static final double FAST_POWER = -1.0;
    public static final double SLOW_POWER = -0.2;

    // Your original protection settings (keep whatever you had)
    private static final double CURRENT_LIMIT_AMPS = 3.0;
    private static final long JAM_TIME_MS = 1000;

    private boolean currentTripped = false;
    private boolean commandedOn = false;
    private double commandedPower = FAST_POWER;

    private long overCurrentStartMs = -1;

    // ✅ NEW: bypass flag (RB will enable this)
    private boolean bypassCurrentLimit = false;

    public Intake(final HardwareMap hwMap, final String name) {
        intakeMotor = hwMap.get(DcMotorEx.class, name);
    }

    /** RB will set this true to ignore current detection */
    public void setBypassCurrentLimit(boolean bypass) {
        bypassCurrentLimit = bypass;
        if (bypass) {
            // When bypassing, don't keep old trip/timers around
            currentTripped = false;
            overCurrentStartMs = -1;
        }
    }

    public boolean isBypassingCurrentLimit() {
        return bypassCurrentLimit;
    }

    public void enable() {
        commandedOn = true;
        commandedPower = FAST_POWER;
    }

    public void slowEnable() {
        commandedOn = true;
        commandedPower = SLOW_POWER;
    }

    public void disable() {
        commandedOn = false;
        intakeMotor.setPower(0.0);
    }

    public void resetCurrentTrip() {
        currentTripped = false;
        overCurrentStartMs = -1;
    }

    public boolean isCurrentTripped() {
        return currentTripped;
    }

    public double getCurrentAmps() {
        return intakeMotor.getCurrent(CurrentUnit.AMPS);
    }

    @Override
    public void periodic() {
        long now = System.currentTimeMillis();

        // ✅ If bypass enabled, ignore current detection entirely
        if (bypassCurrentLimit) {
            intakeMotor.setPower(commandedOn ? commandedPower : 0.0);
            return;
        }

        // ---- Normal LB mode protection ----
        double amps = intakeMotor.getCurrent(CurrentUnit.AMPS);

        if (!currentTripped && commandedOn) {
            if (amps > CURRENT_LIMIT_AMPS) {
                if (overCurrentStartMs < 0) overCurrentStartMs = now;

                if (now - overCurrentStartMs >= JAM_TIME_MS) {
                    currentTripped = true;
                    commandedOn = false;
                    intakeMotor.setPower(0.0);
                    return;
                }
            } else {
                overCurrentStartMs = -1;
            }
        } else {
            overCurrentStartMs = -1;
        }

        intakeMotor.setPower(currentTripped ? 0.0 : (commandedOn ? commandedPower : 0.0));
    }
}
