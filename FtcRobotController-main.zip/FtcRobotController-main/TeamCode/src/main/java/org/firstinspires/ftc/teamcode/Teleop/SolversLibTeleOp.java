// ======================================================
// SolversLibTeleOp + TurretTrack + Hood
// ROBOT-CENTRIC MECANUM DRIVE
//
// SAFETY ADDITION:
// - On INIT + START: NOTHING (shooter/intake/kicker/turret/hood logic) runs until you ARM it.
// - Press START to ARM mechanisms. Drive ALWAYS works.
//
// A          = toggle shooter + hood (1260 TPS)
// DPAD_RIGHT = turret preset + shooter preset + hood (tracking OFF)
// LB         = intake toggle (current protect ON)
// RB (HOLD)  = repeating transfer cycle
// Y          = zero Pinpoint + enable tracking (tracking ON)
// ======================================================
package org.firstinspires.ftc.teamcode.Teleop;

import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;

import com.seattlesolvers.solverslib.command.CommandOpMode;
import com.seattlesolvers.solverslib.command.CommandScheduler;
import com.seattlesolvers.solverslib.command.InstantCommand;
import com.seattlesolvers.solverslib.gamepad.GamepadEx;
import com.seattlesolvers.solverslib.gamepad.GamepadKeys;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;

import org.firstinspires.ftc.teamcode.Commands.Shoot.RunShooter;
import org.firstinspires.ftc.teamcode.Subsystem.BreakBeamSensor;
import org.firstinspires.ftc.teamcode.Subsystem.Intake;
import org.firstinspires.ftc.teamcode.Subsystem.Kicker;
import org.firstinspires.ftc.teamcode.Subsystem.Shooter;
import org.firstinspires.ftc.teamcode.Subsystem.Turret;

@TeleOp(name = "SolversLibTeleOp (Robot Centric)", group = "TeleOp")
public class SolversLibTeleOp extends CommandOpMode {

    private GamepadEx controller;

    // Drive motors
    private DcMotorEx frontLeft, frontRight, backLeft, backRight;

    private Kicker kicker;
    private Intake intake;
    private Shooter shooter;
    private BreakBeamSensor breakBeamSensor;

    // Hood
    private Servo hood;
    private static final double HOOD_SHOOT_POS = 0.24;
    private static final double HOOD_SHOOT_POS2 = 0.28;

    // Turret + Pinpoint
    private Turret turret;
    private GoBildaPinpointDriver pinpoint;

    private static final double GOAL_FIELD_HEADING_DEG = 53.0;

    // Tracking
    private boolean tracking = false;
    private double targetFieldDeg = GOAL_FIELD_HEADING_DEG;

    private boolean yPrev = false;
    private long lastLoopNs = 0L;

    // Shooter
    private boolean shooterOn = false;
    private static final double SHOOT_TPS = 1260.0;
    private static final double PRESET_SHOOT_TPS = 1500.0;
    private double currentShootTPS = SHOOT_TPS;

    // Turret preset
    private static final double PRESET_TURRET_DEG = -68.0;

    // Intake toggle (LB)
    private boolean intakeOn = false;

    // ================= RB HOLD-TO-RUN TRANSFER LOOP =================
    private enum TransferState { IDLE, WAIT_UP, CHECK_BEAM, FEED }
    private TransferState transferState = TransferState.IDLE;
    private long transferStateStartMs = 0L;
    private boolean rbWasHeld = false;

    private static final long KICK_UP_HOLD_MS = 220; // kicker up time
    private static final long FEED_MS = 250;         // intake on time

    // ================= SAFETY ARMING =================
    private boolean armed = false;
    private boolean startPrev = false;
    private boolean shooterCmdScheduled = false;

    @Override
    public void initialize() {
        CommandScheduler.getInstance().enable();
        controller = new GamepadEx(gamepad1);

        // ---- Drive motors ----
        frontLeft  = hardwareMap.get(DcMotorEx.class, "FL");
        frontRight = hardwareMap.get(DcMotorEx.class, "FR");
        backLeft   = hardwareMap.get(DcMotorEx.class, "BL");
        backRight  = hardwareMap.get(DcMotorEx.class, "BR");

        // Directions YOU specified
        frontRight.setDirection(DcMotorSimple.Direction.REVERSE);
        frontLeft.setDirection(DcMotorSimple.Direction.REVERSE);
        backLeft.setDirection(DcMotorSimple.Direction.REVERSE);
        backRight.setDirection(DcMotorSimple.Direction.FORWARD);

        frontLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        frontRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backLeft.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backRight.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        kicker = new Kicker(hardwareMap, "ballKick", telemetry);
        intake = new Intake(hardwareMap, "intake");
        shooter = new Shooter(hardwareMap, "shooter", telemetry);
        breakBeamSensor = new BreakBeamSensor(hardwareMap);

        // Requires your updated Shooter class that includes setUseDashTarget()
        shooter.setUseDashTarget(false);

        hood = hardwareMap.get(Servo.class, "hood");
        hood.setPosition(HOOD_SHOOT_POS);

        turret = new Turret(hardwareMap, "turret");

        pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, "pinpoint");
        pinpoint.setOffsets(-84.0, -168.0, DistanceUnit.MM);
        pinpoint.setEncoderResolution(GoBildaPinpointDriver.GoBildaOdometryPods.goBILDA_4_BAR_POD);
        pinpoint.setEncoderDirections(
                GoBildaPinpointDriver.EncoderDirection.FORWARD,
                GoBildaPinpointDriver.EncoderDirection.FORWARD
        );

        // ================= SAFETY DEFAULTS (INIT-SAFE) =================
        armed = false;
        shooterCmdScheduled = false;

        tracking = false;
        targetFieldDeg = GOAL_FIELD_HEADING_DEG;

        shooterOn = false;
        currentShootTPS = SHOOT_TPS;

        intakeOn = false;
        transferState = TransferState.IDLE;
        rbWasHeld = false;

        kicker.setDown();
        intake.disable();
        intake.setBypassCurrentLimit(false);
        shooter.setVelocity(0);

        // IMPORTANT: do NOT schedule shooter command during init
        // schedule(new RunShooter(shooter));

        // ================= BUTTONS =================

        // A: toggle shooter + hood (normal)
        controller.getGamepadButton(GamepadKeys.Button.A)
                .whenPressed(new InstantCommand(() -> {
                    if (!armed) return;

                    shooterOn = !shooterOn;
                    currentShootTPS = SHOOT_TPS;
                    if (shooterOn) hood.setPosition(HOOD_SHOOT_POS);
                }));

        // DPAD_RIGHT: preset shot (tracking OFF)
        controller.getGamepadButton(GamepadKeys.Button.DPAD_RIGHT)
                .whenPressed(new InstantCommand(() -> {
                    if (!armed) return;

                    tracking = false;
                    turret.setTurretDegrees(PRESET_TURRET_DEG);

                    shooterOn = true;
                    currentShootTPS = PRESET_SHOOT_TPS;

                    hood.setPosition(HOOD_SHOOT_POS2);
                    gamepad1.rumble(300);
                }));

        // LB: intake toggle (current protect ON)
        controller.getGamepadButton(GamepadKeys.Button.LEFT_BUMPER)
                .whenPressed(new InstantCommand(() -> {
                    if (!armed) return;

                    intakeOn = !intakeOn;

                    // RB has priority over intake while held
                    if (!gamepad1.right_bumper) {
                        intake.setBypassCurrentLimit(false);

                        if (intakeOn) {
                            intake.resetCurrentTrip();
                            intake.enable();
                        } else {
                            intake.disable();
                        }
                    }
                }));

        lastLoopNs = System.nanoTime();
    }

    @Override
    public void run() {
        super.run();

        // ==================================================
        // ROBOT-CENTRIC MECANUM DRIVE (ALWAYS ENABLED)
        // ==================================================
        double y  = -gamepad1.left_stick_y;
        double x  =  gamepad1.left_stick_x;
        double rx =  gamepad1.right_stick_x;

        x *= 1.10; // strafe correction

        double fl = y + x + rx;
        double bl = y - x + rx;
        double fr = y - x - rx;
        double br = y + x - rx;

        double max = Math.max(1.0, Math.max(
                Math.max(Math.abs(fl), Math.abs(bl)),
                Math.max(Math.abs(fr), Math.abs(br))
        ));

        fl /= max; bl /= max; fr /= max; br /= max;

        double slow = (gamepad1.left_trigger > 0.2) ? 0.4 : 1.0;

        frontLeft.setPower(fl * slow);
        backLeft.setPower(bl * slow);
        frontRight.setPower(fr * slow);
        backRight.setPower(br * slow);

        // ==================================================
        // Pinpoint (safe to update even when not armed)
        // ==================================================
        pinpoint.update();

        long nowNs = System.nanoTime();
        double dt = (nowNs - lastLoopNs) / 1e9;
        lastLoopNs = nowNs;
        if (dt <= 0) dt = 0.02;

        // ==================================================
        // ARMING: press START to enable mechanisms
        // ==================================================
        boolean startBtn = gamepad1.start;
        if (startBtn && !startPrev) {
            armed = !armed;

            if (!armed) {
                // disarm = force everything off immediately
                shooterOn = false;
                tracking = false;
                intakeOn = false;

                transferState = TransferState.IDLE;
                rbWasHeld = false;

                shooter.setVelocity(0);
                intake.disable();
                intake.setBypassCurrentLimit(false);
                kicker.setDown();
            } else {
                // arm = optional schedule shooter controller command now
                if (!shooterCmdScheduled) {
                    schedule(new RunShooter(shooter));
                    shooterCmdScheduled = true;
                }
            }

            gamepad1.rumble(250);
        }
        startPrev = startBtn;

        // ==================================================
        // If NOT ARMED: keep mechanisms OFF and skip logic
        // ==================================================
        if (!armed) {
            shooter.setVelocity(0);
            intake.disable();
            intake.setBypassCurrentLimit(false);
            kicker.setDown();

            telemetry.addLine("NOT ARMED (press START to arm mechanisms)");
            telemetry.addData("armed", false);
            telemetry.update();
            return;
        }

        // ==================================================
        // Y: reset + enable tracking (normal)
        // ==================================================
        boolean yBtn = gamepad1.y;
        if (yBtn && !yPrev) {
            pinpoint.resetPosAndIMU();
            targetFieldDeg = GOAL_FIELD_HEADING_DEG;
            tracking = true;

            // Optional: restore normal speed when returning to tracking
            currentShootTPS = SHOOT_TPS;

            double robotHeadingDeg = getRobotHeadingDeg();
            double targetRobotDeg =
                    turret.clampDegrees(wrapDeg(targetFieldDeg - robotHeadingDeg));
            turret.setTurretDegrees(targetRobotDeg);

            gamepad1.rumble(300);
        }
        yPrev = yBtn;

        // ==================================================
        // Continuous tracking (only when tracking == true)
        // ==================================================
        if (tracking) {
            double robotHeadingDeg = getRobotHeadingDeg();
            double targetRobotDeg =
                    turret.clampDegrees(wrapDeg(targetFieldDeg - robotHeadingDeg));
            turret.setTurretDegrees(targetRobotDeg);
        }

        // ==================================================
        // Shooter
        // ==================================================
        shooter.setVelocity(shooterOn ? currentShootTPS : 0.0);

        // ==================================================
        // RB (HOLD): repeating transfer loop
        // ==================================================
        boolean rbHeld = gamepad1.right_bumper;
        long nowMs = System.currentTimeMillis();

        // If RB is newly held, start cycle
        if (rbHeld && !rbWasHeld) {
            // RB takes over intake
            intakeOn = false;

            intake.disable();                 // step 1: intake OFF
            intake.setBypassCurrentLimit(true);

            kicker.setUp();                   // step 2: kicker UP
            transferState = TransferState.WAIT_UP;
            transferStateStartMs = nowMs;
        }

        // If RB released, stop everything safely
        if (!rbHeld && rbWasHeld) {
            intake.disable();
            intake.setBypassCurrentLimit(false);
            kicker.setDown();

            transferState = TransferState.IDLE;
        }

        rbWasHeld = rbHeld;

        if (rbHeld) {
            boolean beamBroken = breakBeamSensor.isBeamBroken();

            switch (transferState) {

                case WAIT_UP:
                    if (nowMs - transferStateStartMs >= KICK_UP_HOLD_MS) {
                        kicker.setDown();
                        transferState = TransferState.CHECK_BEAM;
                        transferStateStartMs = nowMs;
                    }
                    break;

                case CHECK_BEAM:
                    if (beamBroken) {
                        intake.enable();
                        transferState = TransferState.FEED;
                        transferStateStartMs = nowMs;
                    }
                    break;

                case FEED:
                    if (nowMs - transferStateStartMs >= FEED_MS) {
                        intake.disable();

                        kicker.setUp();
                        transferState = TransferState.WAIT_UP;
                        transferStateStartMs = nowMs;
                    }
                    break;

                case IDLE:
                default:
                    intake.disable();
                    kicker.setDown();
                    transferState = TransferState.IDLE;
                    break;
            }
        } else {
            // if RB not held, respect LB intake toggle
            intake.setBypassCurrentLimit(false);
            if (intakeOn) {
                intake.enable();
            } else {
                intake.disable();
            }
        }

        // ==================================================
        // Telemetry (debug)
        // ==================================================
        telemetry.addData("armed", armed);
        telemetry.addData("tracking", tracking);
        telemetry.addData("rbHeld", rbHeld);
        telemetry.addData("transferState", transferState);
        telemetry.addData("beamBroken", breakBeamSensor.isBeamBroken());
        telemetry.addData("kickerPos", kicker.getLastPosition());
        telemetry.addData("shOn", shooterOn);
        telemetry.addData("shTPS", currentShootTPS);
        telemetry.addData("shVel", shooter.getCurrentVelocity());
        telemetry.addData("turDeg", turret.getDegrees());
        telemetry.update();
    }

    private double getRobotHeadingDeg() {
        return wrapDeg(Math.toDegrees(
                pinpoint.getHeading(AngleUnit.RADIANS)
        ));
    }

    private static double wrapDeg(double d) {
        d = (d + 180.0) % 360.0;
        if (d < 0) d += 360.0;
        return d - 180.0;
    }
}
