package org.firstinspires.ftc.teamcode.Auton;

import com.pedropathing.control.PIDFCoefficients;
import com.pedropathing.control.PIDFController;
import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.PathChain;
import com.pedropathing.util.Timer;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.Servo;

import com.qualcomm.robotcore.util.Range;

import org.firstinspires.ftc.teamcode.Pedro.Constants;

/**
 * Blue_Front15point (MIRRORED VERSION OF Red_Front15point)
 *
 * Mirror math used (Red -> Blue):
 * - x' = 144 - x
 * - y' = y
 * - headingDeg' = (180 - headingDeg) mod 360
 *
 * Notes:
 * - pickupHeading was 0 on red -> becomes 180 on blue
 * - constant 90deg stays 90deg
 */
@Autonomous(name = "Blue_Front15point", group = "Auton")
public class Blue_Front15point extends OpMode {

    // ------------------- Pedro -------------------
    private Follower follower;
    private Timer pathTimer, opmodeTimer;
    private int pathState;

    // ------------------- Hardware -------------------
    private Servo ballStopper = null;   // kicker servo ("ballKick")
    private Servo hood = null;          // hood servo
    private Servo turret = null;        // turret servo (FIXED)

    private DcMotorEx ShooterMotor = null;
    private DcMotor IntakeMotor = null;

    private DigitalChannel beamBreakSensor = null; // active-low breakbeam

    // ------------------- Shooter PID -------------------
    private PIDFController b, s;

    public static double bp = 0.02, bd = 0.0, bf = 0.0,
            sp = 0.02, sd = 0.0001, sf = 0.0;

    private double pSwitch = 50;

    // ------------------- Timing / Powers -------------------
    private double waittime = 0.22;
    private double waittime_transfer = 0.22;

    private double power_pickup = 1.0;
    private double power_shooting = 1.0;

    private double pickupIntakePower = -1.0;

    // ADDED (kicker-cycle intake powers, matches your other code)
    private double searchIntakePower = -0.4;     // beam not broken yet
    private double transferIntakePower = -1.0;   // once beam is broken

    // Kicker positions
    private double ballkicker_up = 0.22;
    private double ballkicker_down = 0.50;

    // Shooter velocities
    private double nearvelocity = 1200;
    private double targetvel = nearvelocity;

    private static final int SHOT_CYCLES = 3;

    // ------------------- Turret (FIXED) -------------------
    private static final String TURRET_SERVO_NAME = "turret";
    private static final double TURRET_CENTER_POS = 0.50;
    private static final double TURRET_DEG_PER_POS = 355.0*0.869;
    private static final double SERVO_MIN_POS = 0.0;
    private static final double SERVO_MAX_POS = 1.0;

    private static final double TURRET_FIXED_DEG = -45.0;
    private static final double TURRET_PRELOAD_DEG = 0.0;


    // =========================================================
    // ------------------- BLUE-MIRRORED POSES -------------------
    // Red -> Blue mirror: x' = 144-x, y' = y, heading' = (180-heading) mod 360
    // =========================================================

    // Red: (121,125,36deg) -> Blue: (23,125,144deg)
    private final Pose startPose = new Pose(23, 125, Math.toRadians(144));

    // Red: (87,85,36) -> Blue: (57,85,144)
    private final Pose scorePose  = new Pose(57, 85, Math.toRadians(144)); // preload

    // Red: (90,85,0) -> Blue: (54,85,180)
    private final Pose scorePose1 = new Pose(54, 85, Math.toRadians(180)); // normal shots
    private final Pose scorePose2 = new Pose(54, 85, Math.toRadians(180)); // last shots

    // Red: (102,85,0) -> Blue: (42,85,180)
    private final Pose Park = new Pose(42, 85, Math.toRadians(180));

    // Lane 1
    // Red: (125,85,0) -> Blue: (19,85,180)
    private final Pose pickup3Pose_lane1 = new Pose(19, 85, Math.toRadians(180));

    // Lane 2
    // Red: (96,59,0) -> Blue: (48,59,180)
    private final Pose pickup1Pose_lane2 = new Pose(48, 59, Math.toRadians(180));
    // Red: (124,59,0) -> Blue: (20,59,180)
    private final Pose pickup3Pose_lane2 = new Pose(20, 59, Math.toRadians(180));

    // Lane 3
    // Red: (96,35,0) -> Blue: (48,35,180)
    private final Pose pickup1Pose_lane3 = new Pose(48, 35, Math.toRadians(180));
    // Red: (124,35,0) -> Blue: (20,35,180)
    private final Pose pickup3Pose_lane3 = new Pose(20, 35, Math.toRadians(180));

    // Slider poses (UPDATED)
    // Red: (130,68,0) -> Blue: (14,68,180)
    private final Pose pickupPose_slider   = new Pose(14, 68, Math.toRadians(180));
    // Red: (134,43,90) -> Blue: (10,43,90)
    private final Pose pushPose_slider     = new Pose(10, 43, Math.toRadians(90));
    // Red: (134,49,90) -> Blue: (10,49,90)
    private final Pose pickupPose1_slider  = new Pose(10, 49, Math.toRadians(90));
    // Red: (117,72.5,0) -> Blue: (27,72.5,180) (kept, not used)
    private final Pose pickupPose1_slider1 = new Pose(27, 72.5, Math.toRadians(180));

    // ------------------- Paths/Chains -------------------
    private PathChain scorePreload;

    private PathChain grabPickup1_lane1;
    private PathChain scorePickup1;

    private PathChain grabPickup1_lane2;
    private PathChain grabPickup3_lane2;
    private PathChain scorePickup2;

    private PathChain grabPickup1_lane3;
    private PathChain grabPickup3_lane3;
    private PathChain scorePickup3;

    // Slider paths
    private PathChain grabPickup_slider;
    private PathChain push_slider;
    private PathChain grabPickup1_slider;
    private PathChain scorePickupslider;

    private PathChain park;

    // =========================================================
    // NON-BLOCKING "SHOOT CYCLES" STATE MACHINE (UNCHANGED)
    // =========================================================
    private boolean transferActive = false;
    private int transferCyclesTarget = 0;
    private int transferCyclesDone = 0;

    private int transferPhase = 0;

    private double beamTimeoutSec = 1.0;
    private double phaseStartSec = 0.0;

    private double activeTransferIntakePower = 0.0;

    private void startBeamGatedTransfers(int cycles) {
        transferActive = true;
        transferCyclesTarget = cycles;
        transferCyclesDone = 0;

        transferPhase = 0;
        phaseStartSec = opmodeTimer.getElapsedTimeSeconds();

        activeTransferIntakePower = 0.0;

        if (IntakeMotor != null) IntakeMotor.setPower(0.0);
        if (ballStopper != null) ballStopper.setPosition(ballkicker_down);
    }

    private boolean updateBeamGatedTransfers() {
        if (!transferActive) return true;

        double now = opmodeTimer.getElapsedTimeSeconds();
        double dt = now - phaseStartSec;

        if (transferCyclesDone >= transferCyclesTarget) {
            transferActive = false;
            if (IntakeMotor != null) IntakeMotor.setPower(0.0);
            if (ballStopper != null) ballStopper.setPosition(ballkicker_down);
            return true;
        }

        switch (transferPhase) {

            case 0: { // kicker up
                if (ballStopper != null) ballStopper.setPosition(ballkicker_up);

                if (IntakeMotor != null) IntakeMotor.setPower(0.0);

                if (dt >= waittime) {
                    transferPhase = 1;
                    phaseStartSec = now;

                    if (ballStopper != null) ballStopper.setPosition(ballkicker_down);

                    activeTransferIntakePower = searchIntakePower;
                    if (IntakeMotor != null) IntakeMotor.setPower(activeTransferIntakePower);
                }
                break;
            }

            case 1: { // kicker down + wait for beam (or timeout)
                boolean broken = isBeamBroken();

                if (broken) {
                    activeTransferIntakePower = transferIntakePower;
                    if (IntakeMotor != null) IntakeMotor.setPower(activeTransferIntakePower);

                    transferPhase = 2;
                    phaseStartSec = now;
                    break;
                }

                activeTransferIntakePower = searchIntakePower;
                if (IntakeMotor != null) IntakeMotor.setPower(activeTransferIntakePower);

                if (dt >= beamTimeoutSec) {
                    transferPhase = 2;
                    phaseStartSec = now;
                }
                break;
            }

            case 2: { // settle
                if (IntakeMotor != null) IntakeMotor.setPower(activeTransferIntakePower);

                if (dt >= waittime_transfer) {
                    transferCyclesDone++;
                    transferPhase = 0;
                    phaseStartSec = now;

                    if (IntakeMotor != null) IntakeMotor.setPower(0.0);
                    if (ballStopper != null) ballStopper.setPosition(ballkicker_down);

                    activeTransferIntakePower = 0.0;
                }
                break;
            }
        }
        return false;
    }

    // ------------------- Intake helpers -------------------
    private void startLaneIntake() {
        if (IntakeMotor != null) IntakeMotor.setPower(pickupIntakePower);
    }

    private void stopLaneIntake() {
        if (IntakeMotor != null) IntakeMotor.setPower(0.0);
    }

    // ------------------- Turret helpers -------------------
    private static double turretDegToServoPos(double turretDeg) {
        double servoPos = TURRET_CENTER_POS + (turretDeg / TURRET_DEG_PER_POS);
        return Range.clip(servoPos, SERVO_MIN_POS, SERVO_MAX_POS);
    }

    private void setTurretDeg(double deg) {
        if (turret != null) turret.setPosition(turretDegToServoPos(deg));
    }

    // ------------------- Breakbeam helpers -------------------
    private boolean isBeamBroken() {
        return beamBreakSensor != null && !beamBreakSensor.getState();
    }

    // ------------------- Shooter PID update -------------------
    private void updateShooterPID() {
        if (ShooterMotor == null) return;

        double currentvel = ShooterMotor.getVelocity();

        b.setCoefficients(new PIDFCoefficients(bp, 0, bd, bf));
        s.setCoefficients(new PIDFCoefficients(sp, 0, sd, sf));

        if (Math.abs(targetvel - currentvel) < pSwitch) {
            s.updateError(targetvel - currentvel);
            ShooterMotor.setPower(s.run());
        } else {
            b.updateError(targetvel - currentvel);
            ShooterMotor.setPower(b.run());
        }
    }

    // ------------------- Build paths -------------------
    public void buildPaths() {

        scorePreload = follower.pathBuilder()
                .addPath(new BezierLine(startPose, scorePose))
                .setLinearHeadingInterpolation(startPose.getHeading(), scorePose.getHeading())
                .build();

        // Red was 0; mirrored back to Blue is 180
        double pickupHeading = Math.toRadians(180);

        grabPickup1_lane1 = follower.pathBuilder()
                .addPath(new BezierLine(scorePose, pickup3Pose_lane1))
                .setConstantHeadingInterpolation(pickupHeading)
                .build();

        scorePickup1 = follower.pathBuilder()
                .addPath(new BezierLine(pickup3Pose_lane1, scorePose1))
                .setLinearHeadingInterpolation(pickup3Pose_lane1.getHeading(), scorePose1.getHeading())
                .build();

        grabPickup1_lane2 = follower.pathBuilder()
                .addPath(new BezierLine(scorePose1, pickup1Pose_lane2))
                .setConstantHeadingInterpolation(pickupHeading)
                .build();

        grabPickup3_lane2 = follower.pathBuilder()
                .addPath(new BezierLine(pickup1Pose_lane2, pickup3Pose_lane2))
                .setConstantHeadingInterpolation(pickupHeading)
                .build();

        scorePickup2 = follower.pathBuilder()
                .addPath(new BezierLine(pickup3Pose_lane2, scorePose1))
                .setLinearHeadingInterpolation(pickup3Pose_lane2.getHeading(), scorePose1.getHeading())
                .build();

        grabPickup1_lane3 = follower.pathBuilder()
                .addPath(new BezierLine(scorePose1, pickup1Pose_lane3))
                .setConstantHeadingInterpolation(pickupHeading)
                .build();

        grabPickup3_lane3 = follower.pathBuilder()
                .addPath(new BezierLine(pickup1Pose_lane3, pickup3Pose_lane3))
                .setConstantHeadingInterpolation(pickupHeading)
                .build();

        scorePickup3 = follower.pathBuilder()
                .addPath(new BezierLine(pickup3Pose_lane3, scorePose2))
                .setLinearHeadingInterpolation(pickup3Pose_lane3.getHeading(), scorePose2.getHeading())
                .build();

        grabPickup_slider = follower.pathBuilder()
                .addPath(new BezierLine(scorePose2, pickupPose_slider))
                .setLinearHeadingInterpolation(scorePose2.getHeading(), pickupPose_slider.getHeading())
                .build();

        push_slider = follower.pathBuilder()
                .addPath(new BezierLine(pickupPose_slider, pushPose_slider))
                .setConstantHeadingInterpolation(Math.toRadians(90))
                .build();

        grabPickup1_slider = follower.pathBuilder()
                .addPath(new BezierLine(pushPose_slider, pickupPose1_slider))
                .setConstantHeadingInterpolation(Math.toRadians(90))
                .build();

        scorePickupslider = follower.pathBuilder()
                .addPath(new BezierLine(pickupPose1_slider, scorePose2))
                .setLinearHeadingInterpolation(pickupPose1_slider.getHeading(), scorePose2.getHeading())
                .build();

        park = follower.pathBuilder()
                .addPath(new BezierLine(scorePose2, Park))
                .setLinearHeadingInterpolation(scorePose2.getHeading(), Park.getHeading())
                .build();
    }

    // ------------------- State constants -------------------
    private static final int SHOOT_PRELOAD_STATE      = 101;
    private static final int SHOOT_AFTER_LANE1_STATE  = 105;
    private static final int SHOOT_AFTER_LANE2_STATE  = 109;
    private static final int SHOOT_AFTER_LANE3_STATE  = 113;
    private static final int SHOOT_AFTER_SLIDER_STATE = 117;

    // ------------------- Main auton state machine -------------------
    public void autonomousPathUpdate() {
        switch (pathState) {

            case 0:
                follower.setMaxPower(power_shooting);
                setTurretDeg(TURRET_PRELOAD_DEG);   // PRELOAD turret aim

                follower.followPath(scorePreload);
                setPathState(1);
                break;

            case 1:
                if (!follower.isBusy()) {
                    setTurretDeg(TURRET_PRELOAD_DEG);   // PRELOAD turret aim
                    startBeamGatedTransfers(SHOT_CYCLES);
                    setPathState(SHOOT_PRELOAD_STATE);
                }
                break;


            case SHOOT_PRELOAD_STATE:
                if (updateBeamGatedTransfers()) {
                    setTurretDeg(TURRET_FIXED_DEG);   // PRELOAD turret aim

                    startLaneIntake();
                    follower.setMaxPower(power_pickup);
                    follower.followPath(grabPickup1_lane1, true);
                    setPathState(3);
                }
                break;


            case 3:
                if (!follower.isBusy() || pathTimer.getElapsedTimeSeconds() > 2.0) {
                    stopLaneIntake();
                    follower.setMaxPower(power_shooting);
                    follower.followPath(scorePickup1, true);
                    setPathState(4);
                }
                break;

            case 4:
                if (!follower.isBusy()) {
                    startBeamGatedTransfers(SHOT_CYCLES);
                    setPathState(SHOOT_AFTER_LANE1_STATE);
                }
                break;

            case SHOOT_AFTER_LANE1_STATE:
                if (updateBeamGatedTransfers()) {
                    startLaneIntake();
                    follower.setMaxPower(power_pickup);
                    follower.followPath(grabPickup1_lane2, true);
                    setPathState(6);
                }
                break;

            case 6:
                if (!follower.isBusy() || pathTimer.getElapsedTimeSeconds() > 2.0) {
                    follower.followPath(grabPickup3_lane2, true);
                    setPathState(7);
                }
                break;

            case 7:
                if (!follower.isBusy() || pathTimer.getElapsedTimeSeconds() > 2.0) {
                    stopLaneIntake();
                    follower.setMaxPower(power_shooting);
                    follower.followPath(scorePickup2, true);
                    setPathState(8);
                }
                break;

            case 8:
                if (!follower.isBusy()) {
                    startBeamGatedTransfers(SHOT_CYCLES);
                    setPathState(SHOOT_AFTER_LANE2_STATE);
                }
                break;

            case SHOOT_AFTER_LANE2_STATE:
                if (updateBeamGatedTransfers()) {
                    startLaneIntake();
                    follower.setMaxPower(power_pickup);
                    follower.followPath(grabPickup1_lane3, true);
                    setPathState(10);
                }
                break;

            case 10:
                if (!follower.isBusy() || pathTimer.getElapsedTimeSeconds() > 2.0) {
                    follower.followPath(grabPickup3_lane3, true);
                    setPathState(11);
                }
                break;

            case 11:
                if (!follower.isBusy() || pathTimer.getElapsedTimeSeconds() > 2.0) {
                    stopLaneIntake();
                    targetvel = nearvelocity;
                    follower.setMaxPower(power_shooting);
                    follower.followPath(scorePickup3, true);
                    setPathState(12);
                }
                break;

            case 12:
                if (!follower.isBusy()) {
                    startBeamGatedTransfers(SHOT_CYCLES);
                    setPathState(SHOOT_AFTER_LANE3_STATE);
                }
                break;

            case SHOOT_AFTER_LANE3_STATE:
                if (updateBeamGatedTransfers()) {
                    startLaneIntake();
                    follower.setMaxPower(power_pickup);
                    follower.followPath(grabPickup_slider, true);
                    setPathState(15);
                }
                break;

            case 15:
                if (!follower.isBusy() || pathTimer.getElapsedTimeSeconds() > 2.5) {
                    follower.followPath(push_slider, true);
                    setPathState(16);
                }
                break;

            case 16:
                if (!follower.isBusy() || pathTimer.getElapsedTimeSeconds() > 2.5) {
                    follower.followPath(grabPickup1_slider, true);
                    setPathState(17);
                }
                break;

            case 17:
                if (!follower.isBusy() || pathTimer.getElapsedTimeSeconds() > 2.5) {
                   // stopLaneIntake();
                    follower.setMaxPower(power_shooting);
                    follower.followPath(scorePickupslider, true);
                    setPathState(18);
                }
                break;

            case 18:
                if (!follower.isBusy()) {
                    targetvel = nearvelocity;
                    startBeamGatedTransfers(SHOT_CYCLES);
                    setPathState(SHOOT_AFTER_SLIDER_STATE);
                }
                break;

            case SHOOT_AFTER_SLIDER_STATE:
                if (updateBeamGatedTransfers()) {
                    follower.setMaxPower(power_shooting);
                    follower.followPath(park, true);
                    setPathState(-1);
                }
                break;

            default:
                break;
        }
    }

    public void setPathState(int pState) {
        pathState = pState;
        pathTimer.resetTimer();
    }

    @Override
    public void loop() {
        updateShooterPID();
        follower.update();
        autonomousPathUpdate();

        telemetry.addData("pathState", pathState);
        telemetry.addData("x", follower.getPose().getX());
        telemetry.addData("y", follower.getPose().getY());
        telemetry.addData("heading(deg)", Math.toDegrees(follower.getPose().getHeading()));
        telemetry.addData("beamBroken(downConfirm)", isBeamBroken());
        telemetry.addData("transferActive", transferActive);
        telemetry.addData("transferPhase", transferPhase);
        telemetry.addData("transferDone/Target", transferCyclesDone + " / " + transferCyclesTarget);
        telemetry.addData("intakePower", (IntakeMotor != null) ? IntakeMotor.getPower() : 0.0);
        telemetry.addData("shooterVel", (ShooterMotor != null) ? ShooterMotor.getVelocity() : 0.0);
        telemetry.addData("targetVel", targetvel);
        telemetry.update();
    }

    @Override
    public void init() {
        pathTimer = new Timer();
        opmodeTimer = new Timer();
        opmodeTimer.resetTimer();

        follower = Constants.createFollower(hardwareMap);
        buildPaths();
        follower.setStartingPose(startPose);

        ballStopper = hardwareMap.get(Servo.class, "ballKick");
        hood = hardwareMap.get(Servo.class, "hood");
        turret = hardwareMap.get(Servo.class, TURRET_SERVO_NAME);

        IntakeMotor = hardwareMap.get(DcMotor.class, "intake");
        IntakeMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        ShooterMotor = hardwareMap.get(DcMotorEx.class, "shooter");

        beamBreakSensor = hardwareMap.get(DigitalChannel.class, "breakbeam");
        beamBreakSensor.setMode(DigitalChannel.Mode.INPUT);

        if (ballStopper != null) ballStopper.setPosition(ballkicker_down);
        if (hood != null) hood.setPosition(0.24);
        if (IntakeMotor != null) IntakeMotor.setPower(0.0);

        setTurretDeg(TURRET_PRELOAD_DEG);

        b = new PIDFController(new PIDFCoefficients(bp, 0, bd, bf));
        s = new PIDFController(new PIDFCoefficients(sp, 0, sd, sf));
    }

    @Override
    public void start() {
        opmodeTimer.resetTimer();
        setPathState(0);
    }

    @Override
    public void stop() {
        super.stop();
        if (IntakeMotor != null) IntakeMotor.setPower(0.0);
        if (ShooterMotor != null) ShooterMotor.setPower(0.0);
        if (ballStopper != null) ballStopper.setPosition(ballkicker_down);
    }
}
