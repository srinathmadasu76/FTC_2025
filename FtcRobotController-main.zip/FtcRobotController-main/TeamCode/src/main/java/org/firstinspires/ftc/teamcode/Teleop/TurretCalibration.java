package org.firstinspires.ftc.teamcode.Teleop;

import com.qualcomm.hardware.gobilda.GoBildaPinpointDriver;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.DistanceUnit;
import org.firstinspires.ftc.teamcode.Subsystem.Turret;

@TeleOp(name = "Turret Calibration", group = "TeleOp")
public class TurretCalibration extends OpMode {

    private Turret turret;
    private GoBildaPinpointDriver pinpoint;

    private static final double STICK_GAIN = 0.006;
    private static final double POS_STEP = 0.002;

    private boolean resetPrev = false;

    @Override
    public void init() {
        turret = new Turret(hardwareMap, "turret");

        pinpoint = hardwareMap.get(GoBildaPinpointDriver.class, "pinpoint");
        pinpoint.setOffsets(-84.0, -168.0, DistanceUnit.MM);
        pinpoint.setEncoderResolution(GoBildaPinpointDriver.GoBildaOdometryPods.goBILDA_4_BAR_POD);
        pinpoint.setEncoderDirections(
                GoBildaPinpointDriver.EncoderDirection.FORWARD,
                GoBildaPinpointDriver.EncoderDirection.FORWARD
        );

        // Do ONE reset in init
        pinpoint.resetPosAndIMU();

        telemetry.addLine("TURRET CALIBRATION");
        telemetry.addLine("Both bumpers: reset pose+heading to 0 (square to wall first).");
        telemetry.addLine("Stick X / Dpad L-R: move turret, read servo pos + turret degrees.");
        telemetry.addLine("Y: center turret");
        telemetry.addLine("Drive to face basket, read Robot Heading for NET_ZONE_BASKET_HEADING.");
        telemetry.update();
    }

    @Override
    public void loop() {
        pinpoint.update();
        double robotHeading = wrapDeg(Math.toDegrees(pinpoint.getHeading(AngleUnit.RADIANS)));

        // Reset heading/pose (debounced)
        boolean resetPressed = gamepad1.left_bumper && gamepad1.right_bumper;
        if (resetPressed && !resetPrev) {
            pinpoint.resetPosAndIMU();
            gamepad1.rumble(500);
        }
        resetPrev = resetPressed;

        // Manual turret control
        double stick = gamepad1.left_stick_x;
        if (Math.abs(stick) > 0.05) {
            turret.setPosition(turret.getLastPosition() + stick * STICK_GAIN);
        }
        if (gamepad1.dpad_left)  turret.setPosition(turret.getLastPosition() - POS_STEP);
        if (gamepad1.dpad_right) turret.setPosition(turret.getLastPosition() + POS_STEP);

        if (gamepad1.y) {
            turret.setTurretDegrees(0.0);
        }

        telemetry.addLine("==== SERVO ====");
        telemetry.addData("Servo Pos", "%.3f", turret.getLastPosition());

        telemetry.addLine("==== TURRET ====");
        telemetry.addData("Turret Deg", "%.1f", turret.getDegrees());
        telemetry.addData("Turret Range (deg)", "%.1f to %.1f", turret.getMinDegrees(), turret.getMaxDegrees());

        telemetry.addLine("==== HEADING ====");
        telemetry.addData("Robot Heading (deg)", "%.1f", robotHeading);
        telemetry.addLine("Use Robot Heading for NET_ZONE_BASKET_HEADING when facing basket.");

        telemetry.addData("Pinpoint Status", pinpoint.getDeviceStatus());
        telemetry.update();
    }

    private static double wrapDeg(double d) {
        d = (d + 180.0) % 360.0;
        if (d < 0) d += 360.0;
        return d - 180.0;
    }
}
