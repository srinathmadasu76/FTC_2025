package org.firstinspires.ftc.teamcode.Teleop;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name = "Servo Degree Test", group = "Test")
public class ServoDegreeTest extends OpMode {

    private Servo turret;

    // CHANGE THIS to your servo name in the config
    private static final String SERVO_NAME = "turretServo";

    // Estimated full mechanical rotation of the servo (you are testing this!)
    private static final double ASSUMED_SERVO_RANGE_DEG = 342.1;

    // Step size per button press
    private static final double STEP = 0.005;

    private double pos = 0.5;

    @Override
    public void init() {
        turret = hardwareMap.get(Servo.class, SERVO_NAME);
        turret.setPosition(pos);
    }

    @Override
    public void loop() {

        // D-pad up/down to move servo safely
        if (gamepad1.dpad_up) {
            pos += STEP;
        } else if (gamepad1.dpad_down) {
            pos -= STEP;
        }

        // Clamp to valid servo range
        pos = Math.max(0.0, Math.min(1.0, pos));
        turret.setPosition(pos);

        // Convert position -> degrees (for display)
        double servoDeg = (pos - 0.5) * ASSUMED_SERVO_RANGE_DEG;

        telemetry.addLine("=== SERVO DEGREE TEST ===");
        telemetry.addData("Servo Position (0-1)", pos);
        telemetry.addData("Estimated Servo Degrees", servoDeg);
        telemetry.addData("Estimated Total Range", ASSUMED_SERVO_RANGE_DEG);
        telemetry.addLine("");
        telemetry.addLine("D-pad UP: +pos");
        telemetry.addLine("D-pad DOWN: -pos");

        telemetry.update();
    }
}
